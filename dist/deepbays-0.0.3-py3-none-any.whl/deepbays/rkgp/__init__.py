from .theory_1HL_FC import FC_1HL
from .theory_1HL_FC_spectral import FC_1HL_spectral
from .theory_deep_FC import FC_deep
from .theory_1HL_FC_multitask import FC_1HL_multitask