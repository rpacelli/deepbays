from .tasks import cifar_dataset
from .tasks import emnist_dataset
from .tasks import mnist_dataset