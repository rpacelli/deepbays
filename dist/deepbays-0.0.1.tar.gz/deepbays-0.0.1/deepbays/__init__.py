from .theory_1HL_FC import prop_width_GP_1HL_FC
from .theory_deep_FC import prop_width_GP_deep_FC
from .theory_multitask import prop_width_GP_1HL_multitask
from .kernels import kernel_erf, kernel_relu
