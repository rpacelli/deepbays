from .classic_tasks import cifar_dataset
from .classic_tasks import mnist_dataset
from .extra_tasks import emnistABFL_CHIS
from .extra_tasks import emnistABEL_CHJS
from .synthetic_tasks import synthetic_1hl_dataset
from .synthetic_tasks import perceptron_dataset